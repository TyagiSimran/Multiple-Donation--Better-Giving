<?php
    include 'db_con.php';
    session_start();
    $showAlert = false;
    $existUser = false;
    $passMiss = false;
    $exists = false;
    if(isset($_POST['submit'])){
        $fname=$_POST['fname'];
        $lname=$_POST['lname'];
        $phone=$_POST['contact'];
        $email=$_POST['email'];
        $age=$_POST['age'];
        $blood_type=$_POST['blood_type'];
        $house=$_POST['place'];
        $town=$_POST['town'];
        $pin=$_POST['pin'];
        $district=$_POST['district'];
        $pass = $_POST['pass'];
        $cpass = $_POST['cpass'];

        if($pass == $cpass && $exists == false){
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $sql="insert into users(fname,lname,phoneno,email,pass,age,bloodtyp,house,town,pin,district) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            //prepare statement
            $stmt = $conn->prepare($sql);
    
            //bind paramters
            $stmt->bind_param("sssssssssss", $fname, $lname, $phone, $email, $hash, $age, $blood_type, $house, $town, $pin, $district);
  
            //execute statement
            $stmt->execute();
            $result = $stmt->get_result();
    
            if($result){
                $showAlert = true;
                echo "DATA INSERTED";
            }
        }
        else if($pass != $cpass){
            $passMiss = true;
        }
        else{
            $existUser = true;
        }
        $stmt->close();
    }
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login/Signup</title>
    <link rel="stylesheet" href="../css/explorestyle.css">
</head>
<body>
    <nav class="navbar">
        <div class="navbar-logo">
            <h1>Better Giving</h1>
        </div>
        <ul class="navbar-links">
            <li><a href="../html/index.html">Home</a></li>
            <li><a href="../html/explore.html">Explore Campaigns</a></li>
            <li><a href="../html/start_campaign.html">Start a Campaign</a></li>
            <li><a href="../html/about.html">About</a></li>
            <li><a href="../html/contact.html">Contact Us</a></li>
            <li><a href="../html/login.html">Login/Signup</a></li>
        </ul>
    </nav>
        <!-- Login Form -->
    <section class="login-form" >
        <div class="form-container" id="login-container">
            <h2>Login</h2>
            <form id="login-form">
                <input type="text" id="login-username" placeholder="Username" required>
                <input type="email" id="login-email" placeholder="Email" required>
                <input type="password" id="login-password" placeholder="Password" required>
                <button type="submit">Login</button>
                <p id="login-error" class="error"></p>
            </form>
            <p>
                Don't have an account? 
                <a href="#" onclick="switchToSignup()">Sign up</a>
            </p>
        </div>

        <!-- Signup Form -->
        <div class="form-container hidden" id="signup-container">
            <h2>Sign Up</h2>
            <form id="signup-form">
                <input type="text" id="signup-username" placeholder="Username" required>
                <input type="email" id="signup-email" placeholder="Email" required>
                <input type="password" id="signup-password" placeholder="Password" required>
                <input type="password" id="signup-confirm-password" placeholder="Confirm Password" required>
                <button type="submit">Sign Up</button>
                <p id="signup-error" class="error"></p>
            </form>
            <p>
                Already have an account? 
                <a href="#" onclick="switchToLogin()">Login</a>
            </p>
        </div>
    </div>
    </section>

    <footer class="footer">
        <p>&copy; 2024 Better Giving | All Rights Reserved</p>
    </footer>
    <script src="../javascript/explorescript.js"></script>
</body>
</html>

