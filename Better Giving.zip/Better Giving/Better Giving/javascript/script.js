// JavaScript for Donation Buttons and Form Validations
document.addEventListener('DOMContentLoaded', () => {
    // Donation Button Event
    const donateButtons = document.querySelectorAll('.donate-button');

    donateButtons.forEach(button => {
        button.addEventListener('click', () => {
            alert('Thank you for your generous donation!');
        });
    });

    // Form Submission Event
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', (event) => {
            event.preventDefault(); // Prevent form from submitting
            alert('Your information has been submitted successfully!');
        });
    });
});
// Function to handle donation
function donate(cause) {
    alert(`Thank you for choosing to support: ${cause}!`);
}

// JavaScript to fix the navbar at the top on scroll
window.onscroll = function() {
    fixNavbar();
};

var navbar = document.querySelector('.navbar');  // Get the navbar element
var sticky = navbar.offsetTop;  // Get the initial position of the navbar

function fixNavbar() {
    if (window.pageYOffset >= sticky) {
        navbar.classList.add("fixed");  // Add the fixed class when the page is scrolled
    } else {
        navbar.classList.remove("fixed");  // Remove the fixed class when the page is at the top
    }
}
// Dummy data for campaigns (replace with dynamic data as needed)
const campaigns = [
    { name: 'Clean Water for All', category: 'all', description: 'Help provide clean water to underprivileged communities.' },
    { name: 'Animal Rescue Mission', category: 'animal', description: 'Help rescue abused animals and provide care.' },
    { name: 'Education for Children', category: 'children', description: 'Provide education to underprivileged children.' },
    { name: 'Elder Care Initiative', category: 'elder', description: 'Support elderly people in need of care.' },
    { name: 'Disaster Relief for Flood Victims', category: 'disaster', description: 'Provide immediate relief to flood victims.' },
];

// Display campaigns based on selected category
function filterCampaigns(category) {
    const filteredCampaigns = category === 'all' ? campaigns : campaigns.filter(campaign => campaign.category === category);
    displayCampaigns(filteredCampaigns);
}

// Display all campaigns
function displayCampaigns(campaignsList) {
    const campaignsContainer = document.getElementById('campaignsList');
    campaignsContainer.innerHTML = ''; // Clear previous campaigns

    campaignsList.forEach(campaign => {
        const campaignCard = document.createElement('div');
        campaignCard.classList.add('campaign-card');
        campaignCard.innerHTML = `
            <h3>${campaign.name}</h3>
            <p>${campaign.description}</p>
            <button class="donate-button">Donate</button>
        `;
        campaignsContainer.appendChild(campaignCard);
    });
}

// Contact form submission
document.querySelector('.contact-form form').addEventListener('submit', (e) => {
    e.preventDefault();
    alert('Message sent to admin!');
});

// Placeholder script for future features
console.log("About page loaded");




