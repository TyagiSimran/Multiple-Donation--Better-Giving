// Get campaign data from localStorage
const campaign = JSON.parse(localStorage.getItem("selectedCampaign"));

if (campaign) {
    // Populate detail page with campaign data
    document.getElementById("campaignTitle").innerText = campaign.title;
    document.getElementById("campaignDescription").innerText = campaign.description;
    document.getElementById("campaignImage").src = campaign.image;
} else {
    // Redirect back to explore page if no data is found
    window.location.href = "../html/explore.html";
}
