// Campaign data
const campaigns = [
    {
        id: 1,
        title: "Healthcare Access",
        description: "Bringing medical care to remote areas.",
        image: "../images/Healthcare.jpg"
    },
    {
        id: 2,
        title: "Education for All",
        description: "Support access to quality education for children in need.",
        image: "../images/education-for-all.jpg.crdownload"
    },
    {
        id: 3,
        title: "Feed the Hungry",
        description: "Provide meals to families and individuals in crisis situations.",
        image: "../images/feed-the-hungry.jpg"
    },
    {
        id: 4,
        title: "Animal Welfare",
        description: "Rescue and care for abused animals.",
        image: "../images/animal-welfare.jpg"
    }
];

// Function to handle card click
function openCampaignDetail(card) {
    const campaignId = card.getAttribute("data-id");
    const selectedCampaign = campaigns.find(campaign => campaign.id == campaignId);

    // Save selected campaign data to localStorage
    localStorage.setItem("selectedCampaign", JSON.stringify(selectedCampaign));

    // Redirect to detail page
    window.location.href = "../html/campaign_detail.html";
}

// javascript for login page
// Switch between login and signup forms
const switchToSignup = () => {
    document.getElementById("login-container").classList.add("hidden");
    document.getElementById("signup-container").classList.remove("hidden");
};

const switchToLogin = () => {
    document.getElementById("signup-container").classList.add("hidden");
    document.getElementById("login-container").classList.remove("hidden");
};

// Handle Login Form Submission
document.getElementById("login-form").addEventListener("submit", async (event) => {
    event.preventDefault(); // Prevent form from refreshing the page
    const username = document.getElementById("login-username").value;
    const email = document.getElementById("login-email").value;
    const password = document.getElementById("login-password").value;

    // Clear previous errors
    const loginError = document.getElementById("login-error");
    loginError.textContent = "";

    // Simulate login API call
    if (email === "test@example.com" && password === "password" && username === "text") {
        alert("Login successful!");
        // Redirect or perform further actions here
    } else {
        loginError.textContent = "Invalid email or password.";
    }
});

// Handle Signup Form Submission
document.getElementById("signup-form").addEventListener("submit", async (event) => {
    event.preventDefault(); // Prevent form from refreshing the page
    const username = document.getElementById("signup-username").value;
    const email = document.getElementById("signup-email").value;
    const password = document.getElementById("signup-password").value;
    const confirmPassword = document.getElementById("signup-confirm-password").value;

    // Clear previous errors
    const signupError = document.getElementById("signup-error");
    signupError.textContent = "";

    // Validate passwords match
    if (password !== confirmPassword) {
        signupError.textContent = "Passwords do not match.";
        return;
    }

    // Simulate signup API call
    if (email && password && username) {
        alert("Signup successful! Please login.");
        switchToLogin();
    } else {
        signupError.textContent = "Signup failed. Please try again.";
    }
});
