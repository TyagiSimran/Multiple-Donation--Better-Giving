<?php
// Database credentials
$servername = "localhost";
$username = "root";
$password = "";
$database = "better_giving_db";

// Create a connection
$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Database connection successful!";

// Close the connection (optional)
$conn->close();
?>
